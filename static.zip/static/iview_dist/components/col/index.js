import col from './col.vue'

export default col