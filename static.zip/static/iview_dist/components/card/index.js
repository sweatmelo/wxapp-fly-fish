import card from './card.vue'

export default card