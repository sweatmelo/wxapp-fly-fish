import message from './message.vue'

export default message