import cell from './cell.vue'

export default cell