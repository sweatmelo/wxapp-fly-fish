import progress from './progress.vue'

export default progress