import steps from './steps.vue'

export default steps