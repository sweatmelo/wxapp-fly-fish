import page from './page.vue'

export default page