import gridLabel from './grid-label.vue'

export default gridLabel