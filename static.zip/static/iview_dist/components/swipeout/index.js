import swipeout from './swipeout.vue'

export default swipeout