import gridIcon from './grid-icon.vue'

export default gridIcon