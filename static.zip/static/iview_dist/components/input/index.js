import input from './input.vue'

export default input