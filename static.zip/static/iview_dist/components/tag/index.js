import tag from './tag.vue'

export default tag