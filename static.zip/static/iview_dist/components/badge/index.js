import badge from './badge.vue'

export default badge