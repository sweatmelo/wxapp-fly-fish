import modal from './modal.vue'

export default modal