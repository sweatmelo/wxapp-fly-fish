import stickyItem from './sticky-item.vue'

export default stickyItem