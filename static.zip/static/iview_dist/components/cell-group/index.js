import cellGroup from './cell-group.vue'

export default cellGroup