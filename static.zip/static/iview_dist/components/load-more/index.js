import loadMore from './load-more.vue'

export default loadMore