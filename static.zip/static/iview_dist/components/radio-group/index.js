import radioGroup from './radio-group.vue'

export default radioGroup