import collapseItem from './collapse-item.vue'

export default collapseItem