import grid from './grid.vue'

export default grid