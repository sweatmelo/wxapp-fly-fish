import step from './step.vue'

export default step