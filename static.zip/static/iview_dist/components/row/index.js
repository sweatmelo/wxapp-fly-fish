import row from './row.vue'

export default row