import iswitch from './switch.vue'

export default iswitch