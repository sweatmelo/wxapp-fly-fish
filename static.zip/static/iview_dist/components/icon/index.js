import icon from './icon.vue'

export default icon