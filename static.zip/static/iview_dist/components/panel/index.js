import panel from './panel.vue'

export default panel