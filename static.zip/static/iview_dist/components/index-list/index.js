import indexList from './index-list.vue'

export default indexList