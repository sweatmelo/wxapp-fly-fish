import tab from './tab.vue'

export default tab