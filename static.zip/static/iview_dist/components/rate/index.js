import rate from './rate.vue'

export default rate