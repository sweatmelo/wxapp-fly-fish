import toast from './toast.vue'

export default toast