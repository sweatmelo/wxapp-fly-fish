import drawer from './drawer.vue'

export default drawer