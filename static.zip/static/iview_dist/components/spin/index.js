import spin from './spin.vue'

export default spin