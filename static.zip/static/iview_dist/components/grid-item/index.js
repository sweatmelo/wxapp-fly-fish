import gridItem from './grid-item.vue'

export default gridItem