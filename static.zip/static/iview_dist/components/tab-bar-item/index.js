import tabBarItem from './tab-bar-item.vue'

export default tabBarItem