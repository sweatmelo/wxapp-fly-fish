import tabs from './tabs.vue'

export default tabs