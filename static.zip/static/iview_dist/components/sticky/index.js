import sticky from './sticky.vue'

export default sticky