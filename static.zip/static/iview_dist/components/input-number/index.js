import inputNumber from './input-number.vue'

export default inputNumber