import divider from './divider.vue'

export default divider