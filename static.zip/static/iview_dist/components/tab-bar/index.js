import tabBar from './tab-bar.vue'

export default tabBar