import checkboxGroup from './checkbox-group.vue'

export default checkboxGroup