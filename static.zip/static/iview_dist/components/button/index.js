import iButton from './button.vue'

export default iButton