import collapse from './collapse.vue'

export default collapse