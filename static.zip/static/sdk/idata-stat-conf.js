exports.appid = "Dc012a1738"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = true; //默认不获取用户坐标位置
exports.debug = false; //默认是debug模式
