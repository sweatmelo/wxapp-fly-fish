const state ={
    current:{
        accent:'mandarin',
        ds:true,
        isDia:false,//发音人配置
        character:'x_xiaoxue',
        //character:'zhongcun',
        //ent: 'int65',
        //city:'',
        latitude: '',
        longitude: ''
    }
}
export default state