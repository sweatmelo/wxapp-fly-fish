const getters={
    current(state){
    return state.current
    }
    }
    
    export default getters