import Vue from 'vue'
import App from './paramDetail'
const app = new Vue(App)
app.$mount()